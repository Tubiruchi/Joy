import {
  require_react
} from "./chunk-TDVGPZLM.js";
export default require_react();
